class DialogSystem {
    constructor() {
        this.currentScene = 0;
        this.story = null;
        this.dialogText = document.getElementById('dialogText');
        this.characterName = document.getElementById('characterName');
        this.choicesContainer = document.getElementById('choices');
        this.currentInterval = null;

        // Sound effects using Tone.js
        if (window.Tone) {
            this.textSound = new Tone.Synth({
                oscillator: { type: "square" },
                volume: -20
            }).toDestination();
        } else {
            console.warn('Tone.js not loaded, sound effects will be disabled');
            this.textSound = null;
        }
    }

    async loadStory() {
        try {
            const response = await fetch('/static/story/story.json');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            this.story = await response.json();
            this.showScene(0);

            // Try to load saved progress
            this.loadProgress();
        } catch (error) {
            console.error('Error loading story:', error);
            throw error;
        }
    }

    showScene(sceneIndex) {
        // Clear any existing animation
        if (this.currentInterval) {
            clearInterval(this.currentInterval);
            this.currentInterval = null;
        }

        if (!this.story || sceneIndex >= this.story.scenes.length) {
            this.dialogText.textContent = 'Конец истории';
            return;
        }

        const scene = this.story.scenes[sceneIndex];
        this.currentScene = sceneIndex;

        // Clear existing text before starting new animation
        this.dialogText.textContent = '';
        this.characterName.textContent = scene.speaker;

        // Start new text animation after a short delay
        setTimeout(() => {
            this.playTextAnimation(scene.text);
        }, 100);

        if (scene.choices) {
            this.showChoices(scene.choices);
        } else {
            this.choicesContainer.innerHTML = '';
        }
    }

    playTextAnimation(text) {
        let i = 0;
        this.dialogText.textContent = '';

        // Store the interval reference so we can clear it later
        this.currentInterval = setInterval(() => {
            if (i < text.length) {
                // Ensure we're adding valid characters
                const nextChar = text.charAt(i);
                this.dialogText.textContent += nextChar;

                if (this.textSound && nextChar.trim() !== '') {
                    this.textSound.triggerAttackRelease("C6", "32n");
                }
                i++;
            } else {
                clearInterval(this.currentInterval);
                this.currentInterval = null;
            }
        }, 50);
    }

    showChoices(choices) {
        this.choicesContainer.innerHTML = '';
        choices.forEach((choice, index) => {
            const button = document.createElement('button');
            button.className = 'choice-button btn btn-outline-info';
            button.textContent = choice.text;
            button.onclick = () => this.makeChoice(index);
            this.choicesContainer.appendChild(button);
        });
    }

    makeChoice(choiceIndex) {
        const scene = this.story.scenes[this.currentScene];
        const nextScene = scene.choices[choiceIndex].nextScene;
        this.showScene(nextScene);
    }

    async saveProgress() {
        try {
            const response = await fetch('/save', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    currentScene: this.currentScene,
                    saveName: 'Quick Save'
                })
            });

            if (!response.ok) {
                const data = await response.json();
                if (response.status === 401) {
                    alert('Пожалуйста, войдите в систему, чтобы сохранить прогресс');
                } else {
                    alert(data.error || 'Не удалось сохранить прогресс');
                }
                return;
            }

            alert('Прогресс успешно сохранен!');
        } catch (error) {
            console.error('Error saving progress:', error);
            alert('Не удалось сохранить прогресс');
        }
    }

    async loadProgress() {
        try {
            const response = await fetch('/load');
            if (!response.ok) {
                if (response.status === 401) {
                    console.log('Необходима авторизация для загрузки прогресса');
                    return;
                }
                throw new Error('Не удалось загрузить прогресс');
            }

            const data = await response.json();
            this.showScene(data.currentScene);
        } catch (error) {
            console.error('Error loading progress:', error);
        }
    }
}