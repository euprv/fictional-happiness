class Game {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.dialogSystem = new DialogSystem();

        this.canvas.width = 800;
        this.canvas.height = 600;

        this.loadedResources = 0;
        this.totalResources = 3; // 2 characters + 1 background

        this.characters = {
            character1: this.loadImage('/static/characters/character1.svg'),
            character2: this.loadImage('/static/characters/character2.svg')
        };

        this.backgrounds = {
            room: this.loadImage('/static/backgrounds/room.svg')
        };

        this.init();
    }

    loadImage(src) {
        const img = new Image();
        img.onload = () => {
            this.loadedResources++;
            if (this.loadedResources === this.totalResources) {
                this.startGame();
            }
        };
        img.onerror = (err) => {
            console.error('Error loading image:', src, err);
        };
        img.src = src;
        return img;
    }

    init() {
        this.setupEventListeners();
        this.render();
    }

    startGame() {
        this.dialogSystem.loadStory().catch(err => {
            console.error('Error loading story:', err);
            this.showError('Failed to load story data');
        });
    }

    showError(message) {
        const dialogText = document.getElementById('dialogText');
        if (dialogText) {
            dialogText.textContent = 'Error: ' + message;
        }
    }

    setupEventListeners() {
        document.getElementById('saveButton').onclick = () => {
            this.dialogSystem.saveProgress();
        };

        document.getElementById('loadButton').onclick = () => {
            this.dialogSystem.loadProgress();
        };

        this.canvas.onclick = () => {
            if (this.dialogSystem.story && 
                !this.dialogSystem.story.scenes[this.dialogSystem.currentScene].choices) {
                this.dialogSystem.showScene(this.dialogSystem.currentScene + 1);
            }
        };
    }

    render() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        // Draw background
        if (this.backgrounds.room.complete) {
            this.ctx.drawImage(this.backgrounds.room, 0, 0, this.canvas.width, this.canvas.height);
        }

        // Draw characters
        const currentScene = this.dialogSystem.story?.scenes[this.dialogSystem.currentScene];
        if (currentScene) {
            if (currentScene.speaker === "Character 1" && this.characters.character1.complete) {
                this.ctx.drawImage(this.characters.character1, 300, 100, 200, 400);
            } else if (currentScene.speaker === "Character 2" && this.characters.character2.complete) {
                this.ctx.drawImage(this.characters.character2, 300, 100, 200, 400);
            }
        }

        requestAnimationFrame(() => this.render());
    }
}

window.addEventListener('load', () => {
    const game = new Game();
});